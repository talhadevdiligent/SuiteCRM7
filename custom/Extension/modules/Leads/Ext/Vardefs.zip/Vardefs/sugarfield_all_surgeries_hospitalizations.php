<?php 
    $dictionary['Lead']['fields']['all_surgeries_hospitalizations'] = array(
        'name' => 'all_surgeries_hospitalizations',
        'vname' => 'LBL_ALL_SURGERIES_HOSPITALIZATIONS',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>