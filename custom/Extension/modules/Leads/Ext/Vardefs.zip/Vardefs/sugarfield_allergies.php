<?php 
    $dictionary['Lead']['fields']['allergies'] = array(
        'name' => 'allergies',
        'vname' => 'LBL_ALLERGIES',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>