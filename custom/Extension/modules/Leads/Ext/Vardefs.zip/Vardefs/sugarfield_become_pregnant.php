<?php 
    $dictionary['Lead']['fields']['become_pregnant'] = array(
        'name' => 'become_pregnant',
        'vname' => 'LBL_BECOME_PREGNANT',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>