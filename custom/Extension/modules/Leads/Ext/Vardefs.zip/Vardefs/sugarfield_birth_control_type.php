<?php 
    $dictionary['Lead']['fields']['birth_control_type'] = array(
        'name' => 'birth_control_type',
        'vname' => 'LBL_BIRTH_CONTROL_TYPE',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>