<?php 
    $dictionary['Lead']['fields']['current_medication_vitamins'] = array(
        'name' => 'current_medication_vitamins',
        'vname' => 'LBL_CURRENT_MEDICATION_VITAMINS',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>