<?php 
    $dictionary['Lead']['fields']['health_goals'] = array(
        'name' => 'health_goals',
        'vname' => 'LBL_HEALTH_GOALS',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>