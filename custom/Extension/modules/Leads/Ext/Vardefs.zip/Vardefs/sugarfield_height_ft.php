<?php 
    $dictionary['Lead']['fields']['height_ft'] = array (
        'name' => 'height_ft',
        'vname' => 'LBL_HEIGHT_FT',
        'type' => 'int',
        'len' => 11,
        'unified_search' => true, 
        'comment' => '',
    );
?>