<?php 
    $dictionary['Lead']['fields']['height_in'] = array (
        'name' => 'height_in',
        'vname' => 'LBL_HEIGHT_IN',
        'type' => 'int',
        'len' => 11,
        'unified_search' => true, 
        'comment' => '',
    );
?>