<?php 
    $dictionary['Lead']['fields']['last_menstrual_cycle'] = array(
        'name' => 'last_menstrual_cycle',
        'vname' => 'LBL_LAST_MENSTRUAL_CYCLE',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>