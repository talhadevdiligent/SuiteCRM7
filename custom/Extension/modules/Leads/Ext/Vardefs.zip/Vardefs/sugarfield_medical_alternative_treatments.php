<?php 
    $dictionary['Lead']['fields']['medical_alternative_treatments'] = array(
        'name' => 'medical_alternative_treatments',
        'vname' => 'LBL_MEDICAL_ALTERNATIVE_TREATMENTS',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>