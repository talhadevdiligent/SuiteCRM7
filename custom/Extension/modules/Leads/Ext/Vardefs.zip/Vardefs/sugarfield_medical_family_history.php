<?php 
    $dictionary['Lead']['fields']['medical_family_history'] = array(
        'name' => 'medical_family_history',
        'vname' => 'LBL_MEDICAL_MEDICAL_FAMILY_HISTORY',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>