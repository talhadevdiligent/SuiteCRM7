<?php 
    $dictionary['Lead']['fields']['medical_history_seek'] = array(
        'name' => 'medical_history_seek',
        'vname' => 'LBL_MEDICAL_HISTORY_SEEK',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>