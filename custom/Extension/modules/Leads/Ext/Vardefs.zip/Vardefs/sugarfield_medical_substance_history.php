<?php 
    $dictionary['Lead']['fields']['medical_substance_history'] = array(
        'name' => 'medical_substance_history',
        'vname' => 'LBL_MEDICAL_SUBSTANCE_HISTORY',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>