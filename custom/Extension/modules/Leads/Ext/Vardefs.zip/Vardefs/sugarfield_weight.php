<?php 
    $dictionary['Lead']['fields']['weight'] = array(
        'name' => 'weight',
        'vname' => 'LBL_WEIGHT',
        'type' => 'varchar',
        'len' => '255',
        'comment' => '',
    );
?>